import { useEffect } from 'react';
import L from 'leaflet';

type Props = {
  lat: number;
  lng: number;
  users: any[];
}

export default function Map({ lat, lng, users }: Props) {
  useEffect(() => {
    const id = 'map';
    let map = L.map(id).setView([lat, lng], 13);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap'
    }).addTo(map);
    const me = L.marker([lat, lng]).addTo(map);
    me.bindPopup('You are here');

    users.forEach(u => {
      if (!u.location?.coordinates) return;
      const [lng2, lat2] = u.location.coordinates;
      const mk = L.marker([lat2, lng2]).addTo(map);
      mk.bindPopup(`${u.name || 'User'}${u.age ? ' • ' + u.age : ''}`);
    });

    return () => { map.remove(); }
  }, [lat, lng, JSON.stringify(users)]);

  return <div id="map" className="map" />;
}
