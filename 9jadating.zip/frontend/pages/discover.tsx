import { useEffect, useState } from 'react';
import dynamic from 'next/dynamic';

const API = process.env.NEXT_PUBLIC_API_URL;
const Map = dynamic(() => import('../shared/Map'), { ssr: false });

type User = {
  _id: string;
  name?: string;
  age?: number;
  gender?: string;
  bio?: string;
  photos?: string[];
  location?: { coordinates: [number, number] };
  lastActive?: string;
};

export default function Discover() {
  const [coords, setCoords] = useState<{lat:number, lng:number} | null>(null);
  const [users, setUsers] = useState<User[]>([]);
  const [error, setError] = useState('');

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(async (pos) => {
        const lat = pos.coords.latitude;
        const lng = pos.coords.longitude;
        setCoords({lat, lng});
        await updateLocation(lat, lng);
        fetchNearby(lat, lng);
      }, () => {
        setError('Location permission denied. Enable it to find nearby matches.');
      });
    } else {
      setError('Geolocation not supported.');
    }
  }, []);

  async function updateLocation(lat:number, lng:number) {
    const token = localStorage.getItem('token');
    if (!token) return;
    await fetch(`${API}/me/location`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
      body: JSON.stringify({ lat, lng })
    });
  }

  async function fetchNearby(lat:number, lng:number) {
    const token = localStorage.getItem('token');
    if (!token) { window.location.href = '/'; return; }
    const res = await fetch(`${API}/users/nearby?lat=${lat}&lng=${lng}&maxKm=10`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    const data = await res.json();
    if (res.ok) setUsers(data.users || []);
  }

  return (
    <div className="container">
      <h2>Discover nearby</h2>
      {error && <p style={{color:'red'}}>{error}</p>}
      {coords && <Map lat={coords.lat} lng={coords.lng} users={users} />}
      <div>
        {users.map(u => (
          <div className="card" key={u._id}>
            <strong>{u.name || 'Anonymous'}</strong> {u.age ? `• ${u.age}` : ''} {u.gender ? `• ${u.gender}` : ''}
            <div>{u.bio || 'No bio yet'}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
