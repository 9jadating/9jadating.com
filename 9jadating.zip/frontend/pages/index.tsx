import { useState } from 'react';

const API = process.env.NEXT_PUBLIC_API_URL;

export default function Home() {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [age, setAge] = useState<number | ''>('');
  const [gender, setGender] = useState('other');
  const [error, setError] = useState('');
  
  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    try {
      const url = isLogin ? '/auth/login' : '/auth/register';
      const body = isLogin ? { email, password } : { email, password, name, age: age ? Number(age) : undefined, gender };
      const res = await fetch(`${API}${url}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed');
      localStorage.setItem('token', data.token);
      window.location.href = '/discover';
    } catch (err: any) {
      setError(err.message);
    }
  }

  return (
    <div className="container">
      <h1>9jadating</h1>
      <p>Find people near you in Nigeria. Free, location-based matching.</p>

      <div className="card">
        <div className="row">
          <button onClick={() => setIsLogin(true)}>Login</button>
          <button onClick={() => setIsLogin(false)}>Register</button>
        </div>
        <form onSubmit={submit}>
          {!isLogin && (
            <>
              <label>Name</label><br />
              <input value={name} onChange={e => setName(e.target.value)} placeholder="Your name" /><br /><br />
              <label>Age</label><br />
              <input type="number" value={age} onChange={e => setAge(e.target.value === '' ? '' : Number(e.target.value))} placeholder="Age" /><br /><br />
              <label>Gender</label><br />
              <select value={gender} onChange={e => setGender(e.target.value)}>
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="other">Other</option>
              </select><br /><br />
            </>
          )}
          <label>Email</label><br />
          <input value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com" /><br /><br />
          <label>Password</label><br />
          <input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="password" /><br /><br />
          <button type="submit">{isLogin ? 'Login' : 'Create account'}</button>
          {error && <p style={{color:'red'}}>{error}</p>}
        </form>
      </div>

      <p style={{opacity:.7}}>After login, we’ll ask for your location to find matches nearby.</p>
    </div>
  );
}
