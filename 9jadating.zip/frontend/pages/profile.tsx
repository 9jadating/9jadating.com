import { useEffect, useState } from 'react';

const API = process.env.NEXT_PUBLIC_API_URL;

export default function Profile() {
  const [user, setUser] = useState<any>(null);
  const [msg, setMsg] = useState('');

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) { window.location.href = '/'; return; }
    fetch(`${API}/me`, { headers: { 'Authorization': `Bearer ${token}` } })
      .then(r => r.json()).then(d => setUser(d.user));
  }, []);

  async function save() {
    const token = localStorage.getItem('token');
    const res = await fetch(`${API}/me`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
      body: JSON.stringify({ name: user.name, age: user.age, gender: user.gender, bio: user.bio })
    });
    if (res.ok) setMsg('Saved!');
  }

  if (!user) return <div className="container"><p>Loading...</p></div>;
  return (
    <div className="container">
      <h2>My Profile</h2>
      <div className="card">
        <label>Name</label><br/>
        <input value={user.name || ''} onChange={e => setUser({...user, name: e.target.value})} /><br/><br/>
        <label>Age</label><br/>
        <input type="number" value={user.age || ''} onChange={e => setUser({...user, age: Number(e.target.value)})} /><br/><br/>
        <label>Gender</label><br/>
        <select value={user.gender || 'other'} onChange={e => setUser({...user, gender: e.target.value})}>
          <option value="male">Male</option><option value="female">Female</option><option value="other">Other</option>
        </select><br/><br/>
        <label>Bio</label><br/>
        <textarea value={user.bio || ''} onChange={e => setUser({...user, bio: e.target.value})} />
        <br/><br/>
        <button onClick={save}>Save</button> {msg && <span>{msg}</span>}
      </div>
    </div>
  );
}
