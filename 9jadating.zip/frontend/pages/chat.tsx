import { useEffect, useState } from 'react';
import { io, Socket } from 'socket.io-client';

const API = process.env.NEXT_PUBLIC_API_URL;

export default function Chat() {
  const [socket, setSocket] = useState<Socket | null>(null);
  const [roomId, setRoomId] = useState('');
  const [from, setFrom] = useState('');
  const [text, setText] = useState('');
  const [messages, setMessages] = useState<any[]>([]);

  useEffect(() => {
    const s = io(API || '');
    setSocket(s);
    s.on('message', (m: any) => {
      setMessages(prev => [...prev, m]);
    });
    return () => { s.disconnect(); }
  }, []);

  const join = () => {
    socket?.emit('joinRoom', { roomId });
  };

  const send = () => {
    socket?.emit('message', { roomId, from, text });
    setText('');
  };

  return (
    <div className="container">
      <h2>Simple Chat (demo)</h2>
      <div className="card">
        <label>Room ID</label><br/>
        <input value={roomId} onChange={e => setRoomId(e.target.value)} placeholder="e.g. userA_userB" /><br/><br/>
        <label>Your Name</label><br/>
        <input value={from} onChange={e => setFrom(e.target.value)} /><br/><br/>
        <button onClick={join}>Join Room</button>
      </div>
      <div className="card">
        <label>Message</label><br/>
        <input value={text} onChange={e => setText(e.target.value)} />
        <button onClick={send}>Send</button>
      </div>
      <div>
        {messages.map((m, i) => (
          <div key={i} className="card">
            <strong>{m.from}</strong>: {m.text} <span style={{opacity:.6}}>{new Date(m.at).toLocaleTimeString()}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
