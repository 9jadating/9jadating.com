import express from 'express';
import dotenv from 'dotenv';
import cors from 'cors';
import mongoose from 'mongoose';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { Server } from 'socket.io';
import http from 'http';

dotenv.config();

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: (process.env.ALLOWED_ORIGINS || '').split(',').map(s => s.trim()).filter(Boolean) || ['*'],
    methods: ['GET','POST','PUT','DELETE'],
    credentials: true
  }
});

app.use(express.json());
app.use(cors({
  origin: (origin, cb) => {
    const allowed = (process.env.ALLOWED_ORIGINS || '').split(',').map(s => s.trim()).filter(Boolean);
    if (!origin || allowed.length === 0 || allowed.includes(origin)) return cb(null, true);
    return cb(new Error('CORS not allowed'));
  },
  credentials: true
}));

// ---- MongoDB ----
const MONGODB_URI = process.env.MONGODB_URI;
if (!MONGODB_URI) {
  console.error('Missing MONGODB_URI in env');
  process.exit(1);
}
await mongoose.connect(MONGODB_URI);
console.log('MongoDB connected');

// ---- Models ----
const userSchema = new mongoose.Schema({
  email: { type: String, unique: true, required: true, index: true },
  passwordHash: { type: String, required: true },
  name: String,
  age: Number,
  gender: { type: String, enum: ['male','female','other'], default: 'other' },
  bio: String,
  interests: [String],
  photos: [String],
  location: {
    type: { type: String, enum: ['Point'], default: 'Point' },
    coordinates: { type: [Number], default: [0,0] } // [lng, lat]
  },
  lastActive: { type: Date, default: Date.now },
  createdAt: { type: Date, default: Date.now }
});
userSchema.index({ location: '2dsphere' });

const User = mongoose.model('User', userSchema);

// ---- Auth Middleware ----
const requireAuth = async (req, res, next) => {
  const auth = req.headers.authorization || '';
  const token = auth.startsWith('Bearer ') ? auth.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'Missing token' });
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET || 'changeme');
    req.userId = payload.id;
    next();
  } catch (e) {
    return res.status(401).json({ error: 'Invalid token' });
  }
};

// ---- Routes ----
app.get('/', (req, res) => {
  res.json({ ok: true, service: '9jadating API' });
});

app.post('/auth/register', async (req, res) => {
  try {
    const { email, password, name, age, gender } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Email & password required' });
    const exists = await User.findOne({ email });
    if (exists) return res.status(400).json({ error: 'Email already in use' });
    const passwordHash = await bcrypt.hash(password, 10);
    const user = await User.create({ email, passwordHash, name, age, gender });
    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET || 'changeme', { expiresIn: '7d' });
    res.json({ token, user: { id: user._id, email: user.email, name: user.name } });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Registration failed' });
  }
});

app.post('/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user) return res.status(400).json({ error: 'Invalid credentials' });
    const ok = await bcrypt.compare(password, user.passwordHash);
    if (!ok) return res.status(400).json({ error: 'Invalid credentials' });
    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET || 'changeme', { expiresIn: '7d' });
    res.json({ token, user: { id: user._id, email: user.email, name: user.name } });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Login failed' });
  }
});

app.get('/me', requireAuth, async (req, res) => {
  const user = await User.findById(req.userId);
  res.json({ user });
});

app.put('/me', requireAuth, async (req, res) => {
  try {
    const { name, age, gender, bio, interests, photos } = req.body;
    const user = await User.findByIdAndUpdate(
      req.userId,
      { $set: { name, age, gender, bio, interests, photos } },
      { new: true }
    );
    res.json({ user });
  } catch (e) {
    res.status(500).json({ error: 'Update failed' });
  }
});

app.post('/me/location', requireAuth, async (req, res) => {
  try {
    const { lat, lng } = req.body;
    if (typeof lat !== 'number' || typeof lng !== 'number') {
      return res.status(400).json({ error: 'Invalid coordinates' });
    }
    const user = await User.findByIdAndUpdate(
      req.userId,
      { $set: { location: { type: 'Point', coordinates: [lng, lat] }, lastActive: new Date() } },
      { new: true }
    );
    res.json({ ok: true, user });
  } catch (e) {
    res.status(500).json({ error: 'Location update failed' });
  }
});

app.get('/users/nearby', requireAuth, async (req, res) => {
  try {
    const { lat, lng, maxKm = 10 } = req.query;
    const latitude = parseFloat(lat);
    const longitude = parseFloat(lng);
    const maxDistanceMeters = parseFloat(maxKm) * 1000;

    if (Number.isNaN(latitude) || Number.isNaN(longitude)) {
      return res.status(400).json({ error: 'lat & lng are required' });
    }

    const users = await User.find({
      _id: { $ne: req.userId },
      location: {
        $near: {
          $geometry: { type: 'Point', coordinates: [longitude, latitude] },
          $maxDistance: maxDistanceMeters
        }
      }
    }).select('name age gender bio photos location lastActive');

    res.json({ users });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Nearby query failed' });
  }
});

// ---- Socket.IO Chat ----
io.on('connection', (socket) => {
  console.log('socket connected', socket.id);

  socket.on('joinRoom', ({ roomId }) => {
    socket.join(roomId);
  });

  socket.on('message', ({ roomId, from, text }) => {
    io.to(roomId).emit('message', { from, text, at: new Date().toISOString() });
  });

  socket.on('disconnect', () => {
    console.log('socket disconnected', socket.id);
  });
});

const PORT = process.env.PORT || 5000;
server.listen(PORT, () => {
  console.log('Server listening on', PORT);
});
